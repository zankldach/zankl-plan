console.log('Zankl Planung – MVP gestartet');
